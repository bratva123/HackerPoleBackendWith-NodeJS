import { Module } from '@nestjs/common';
import { CandidateController } from './candidate/candidate.controller';
import { ExpertiesController } from './experties/experties.controller';
import { VoteController } from './vote/vote.controller';
import { AuthController } from './auth/auth.controller';
import { CandidateModule } from './candidate/candidate.module';
import { CandidateService } from './candidate/candidate.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { typeOrmConfig } from './config/typeOrm.config';
import { CandidateRepository } from './candidate/candidate.repository';
import { ExpertiesRepository } from './experties/experties.repository';
import { VoteRepository } from './vote/vote.repository';
import { VoteService } from './vote/vote.service';
import { VoteModule } from './vote/vote.module';
import { ExpertiesModule } from './experties/experties.module';
import { ExpertiesService } from './experties/experties.service';
import { AuthModule } from './auth/auth.module';
import { AuthService } from './auth/auth.service';
import { AuthRepository } from './auth/auth.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([CandidateRepository,ExpertiesRepository,VoteRepository, AuthRepository]),
    TypeOrmModule.forRoot(typeOrmConfig) ,
    CandidateModule,
    VoteModule,
    ExpertiesModule,
    AuthModule
  ],
  controllers: [ CandidateController, ExpertiesController, VoteController, AuthController],
  providers: [ CandidateService, VoteService , ExpertiesService, AuthService],
})
export class AppModule {}
