import { Body, Controller, Post } from '@nestjs/common';
import { AuthService } from './auth.service';
import { Admin } from '../entities/Admin';

@Controller('auth')
export class AuthController {
  constructor(private authSrv: AuthService) {
  }
  @Post('/signin')
  userAuhentication(@Body() body){
    const user: Admin = body as Admin;
    console.log(user)
    return this.authSrv.getAuthentication(user);

  }
}
