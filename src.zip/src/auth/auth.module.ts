import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthRepository } from './auth.repository';
import { AuthController } from './auth.controller';

@Module({
  imports:[
    TypeOrmModule.forFeature([AuthRepository]),
  ],
  controllers: [ AuthController ],
  providers: [AuthService]

})
export class AuthModule {}
