import { EntityRepository, Repository } from 'typeorm';
import { Admin } from '../entities/Admin';

@EntityRepository(Admin)
export class AuthRepository extends Repository<Admin>{

}
