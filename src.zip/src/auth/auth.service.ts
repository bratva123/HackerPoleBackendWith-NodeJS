import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { AuthRepository } from './auth.repository';
import { Admin } from '../entities/Admin';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(AuthRepository) private authRepo: AuthRepository
  ) {
  }
  async getAuthentication(user: Admin){
    const adminUser = await this.authRepo.findOne(user);
    if(adminUser){
      return user.username;
    }
    else{
      throw new NotFoundException('Invalid credential');
    }
  }
}
