import { Param, Body, Controller, Get, Post, Delete, Patch } from '@nestjs/common';
import { CandidateService } from './candidate.service';
import { Candidate } from '../entities/Candidate';

@Controller('candidate')
export class CandidateController {
  constructor(private candSrv: CandidateService) {
  }
  @Get()
  getAllCandidate(){
    const cands = this.candSrv.getAllCandidate();
    return cands
  }
  @Get('/:name')
  getCandidateByName(@Param('name') name:string){
    const cand = this.candSrv.getCandidateByName(name)
    return cand
  }
  @Post()
  addCandidate(@Body() body){
    const cand :Candidate = body as Candidate;
    console.log(cand)
    return this.candSrv.addCandidate(cand);
  }
  @Delete('/:name')
  deleteCandidate(@Param('name') name: string){
    this.candSrv.deleteCandidate(name);
  }
  @Patch('/:name')
  updateCandDetail(@Param('name') name: string, @Body() body){
    const cand:Candidate = body as Candidate;
    this.candSrv.updateCandDets(name, cand)
  }

}
