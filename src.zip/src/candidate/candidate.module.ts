import { Module } from '@nestjs/common';
import { CandidateController } from './candidate.controller'
import { CandidateService } from './candidate.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CandidateRepository } from './candidate.repository';
import { VoteRepository } from '../vote/vote.repository';
import { VoteService } from '../vote/vote.service';
import { ExpertiesService } from '../experties/experties.service';
import { ExpertiesRepository } from '../experties/experties.repository';
@Module({
  imports:[
     TypeOrmModule.forFeature([CandidateRepository]),
     TypeOrmModule.forFeature([ExpertiesRepository]),
    TypeOrmModule.forFeature([VoteRepository])
  ],
  controllers: [ CandidateController ],
  providers: [CandidateService,VoteService,ExpertiesService] ,
})
export class CandidateModule {

}
