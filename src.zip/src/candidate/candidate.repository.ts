import { EntityRepository, Repository } from 'typeorm';
import { Candidate } from '../entities/Candidate';

@EntityRepository(Candidate)
export class CandidateRepository extends Repository<Candidate>{

}
