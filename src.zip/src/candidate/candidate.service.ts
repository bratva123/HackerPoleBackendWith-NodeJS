import { Injectable, NotFoundException } from '@nestjs/common';
import { CandidateRepository } from './candidate.repository';
import { InjectRepository } from '@nestjs/typeorm';
import { Candidate } from '../entities/Candidate';
import { VoteService } from '../vote/vote.service';
import { Vote } from '../entities/Vote';
import { ExpertiesService } from '../experties/experties.service';
import { VoteRepository } from '../vote/vote.repository';

@Injectable()
export class CandidateService {
constructor(
  @InjectRepository(CandidateRepository) private candRepo: CandidateRepository,
  @InjectRepository(VoteRepository) private voteRepo: VoteRepository,
  private voteSrv:VoteService,
  private expertSrv:ExpertiesService,
){

}

  async getAllCandidate():Promise<Candidate[]>{
      const cands:Candidate[] = await this.candRepo.find()
      return cands
  }
 async getCandidateByName(name: string):Promise<Candidate>{
    const cand = await this.candRepo.findOne(name);
    if(!cand){
      throw new NotFoundException('Candidate with name '+name+' not found')
    }
    return cand
  }
  async addCandidate(cand: Candidate):Promise<Candidate>{
    await this.candRepo.save(cand)
    const vote = new Vote();
    vote.name == cand.name;
    vote.count = 0;
    await this.voteRepo.save(vote)
    return cand
  }
  async deleteCandidate(name: string):Promise<void> {
    this.voteSrv.deleteVoteCand(name);
    this.expertSrv.deleteExperties(name);
    await this.candRepo.delete(name);
  }
  async updateCandDets(name:string, cand:Candidate):Promise<Candidate>{
    this.candRepo.update(name,cand)
    return cand;
  }
}
