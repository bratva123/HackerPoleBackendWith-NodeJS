import { TypeOrmModuleOptions } from '@nestjs/typeorm'

export const typeOrmConfig: TypeOrmModuleOptions = {
    type: 'mysql',
    host: 'localhost',
    username: 'nshkant',
    password: 'nshkant',
    database: 'hackerpoleDb',
    synchronize: true,
    entities: [__dirname + '/../**/*.ts']
};
