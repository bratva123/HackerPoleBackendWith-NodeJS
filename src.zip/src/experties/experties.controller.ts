import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { Candidate } from '../entities/Candidate';
import { ExpertiesService } from './experties.service';
import { Experties } from '../entities/Experties';

@Controller('experties')
export class ExpertiesController {
constructor(private expertSrv:ExpertiesService) {
}
  @Get('/:name')
  getExpertiesByName(@Param('name') name: string) {
    return this.expertSrv.getExpertiesByName(name)
  }

  @Post()
  addExperties(@Body() body) {
    const expert = body as Experties;
    console.log(expert)
    return this.expertSrv.addExperties(expert);
  }

  @Delete('/:name')
  deleteExperties(@Param('name') name: string) {
    this.expertSrv.deleteExperties(name);
  }
}
