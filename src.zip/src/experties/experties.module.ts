import { Module } from '@nestjs/common';
import { ExpertiesService } from './experties.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExpertiesRepository } from './experties.repository';
import { ExpertiesController } from './experties.controller';

@Module({
  imports:[
    TypeOrmModule.forFeature([ExpertiesRepository])
  ],
  controllers: [ ExpertiesController ],
  providers: [ExpertiesService]
})
export class ExpertiesModule {}
