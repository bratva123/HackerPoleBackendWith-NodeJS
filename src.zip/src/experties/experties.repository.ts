import { EntityRepository, Repository } from 'typeorm';
import { Experties } from '../entities/Experties';

@EntityRepository(Experties)
export class ExpertiesRepository extends Repository<Experties>{

}
