import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ExpertiesRepository } from './experties.repository';
import { Experties } from '../entities/Experties';

@Injectable()
export class ExpertiesService {
  constructor(
    @InjectRepository(ExpertiesRepository) private expertRepo: ExpertiesRepository
  ) {

  }
  async getExpertiesByName(name:string):Promise<Experties>{
    const expert:Experties = await this.expertRepo.findOne(name);
    if(!Experties){
      throw new NotFoundException('No data found')
    }
    return  expert;
  }
  async addExperties(expert:Experties):Promise<Experties>{
    await this.expertRepo.save(expert);
    return  expert;
  }
  async deleteExperties(name:string){
    await this.expertRepo.delete(name);
  }
  async updateExperties(name:string, expert:Experties):Promise<Experties>{
    this.expertRepo.update(name, expert)
    return expert
  }
}
