import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { VoteService } from './vote.service';
import { Candidate } from '../entities/Candidate';
import { Vote } from '../entities/Vote';

@Controller('vote')
export class VoteController {
  constructor(private voteSrv:VoteService) {
  }

  @Get('/:name')
  getVote(@Param('name') name:string){
    return this.voteSrv.getVote(name)
  }
  @Patch('/:name')
  updateVote(@Param('name') name){
    console.log(name);
    return this.voteSrv.updatevote(name);
  }
  @Get()
  getAllVotes(){
    return this.voteSrv.getAllVotes();
  }
}
