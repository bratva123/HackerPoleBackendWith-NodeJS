import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { VoteRepository } from './vote.repository';
import { Vote } from '../entities/Vote';

@Injectable()
export class VoteService {
  constructor(
    @InjectRepository(VoteRepository) private voteRepo: VoteRepository
  ) {
  }
  async getAllVotes():Promise<Vote[]>{
    const votes = await this.voteRepo.find()
    return votes
  }
  async getVote(name):Promise<Vote>{
    const vote = await this.voteRepo.findOne(name)
    return  vote
  }
  async addVote(vote: Vote):Promise<Vote>{
    await this.voteRepo.save(vote)
    return  vote
  }
  async updatevote(name:string):Promise<Vote>{
    const vote:Vote = await this.getVote(name);
    vote.count += 1;
    this.voteRepo.save(vote);
    return vote
  }
  async deleteVoteCand(name:string):Promise<void>{
    await this.voteRepo.delete(name);
  }

}
